import java.lang.*;
import java.io.*;
import java.util.*;
public class ac_test{
	
	static Scanner sc=new Scanner(System.in);
	static boolean ending=false;
	static DLBnode dict=new DLBnode();//dictionary trie
	static DLBnode_his his=new DLBnode_his();//user history trie
	static DLBnode dict_p;//pointer of the dictionary trie
	static DLBnode_his his_p;//pointer of the user history trie
	static FileWriter fw;
	static PrintWriter pw;
	static String[] str_a;//output string
	static String s;// input string/ prefix
	static long totaltime;
	static int ct=0;//counter for searches
	public static void creation(){
		//create the dictionary DLB trie
		try{
			File file=new File("dictionary.txt");
			Scanner sc_f=new Scanner(file);
			if(!file.exists()){//file not exist
		        System.out.print("Dictionary File does not exist. ");
	            System.exit(0);
	        }
	        while(sc_f.hasNextLine()){
		        String str=sc_f.nextLine();
		        dict.addNode(str);
	        }
	        sc_f.close();
		}catch(Exception exc){System.out.println(exc);}
		//create the history trie
		try{
			File file=new File("user_history.txt");
			if(!file.createNewFile()){//history has already exist, don't bother create it / otherwise, it creates the file
		        Scanner sc_f=new Scanner(file);
		        while(sc_f.hasNextLine()){
			        String str=sc_f.nextLine();
			        his.addNode(str,0);
		        }
		        sc_f.close();
	    	}
		}catch(Exception exc){System.out.println(exc);}

	}

	public static void quit(){
		double avg=(double) totaltime/ct *0.000001;
		System.out.printf("\n\nAverage time: %.6fs\n",avg);
		System.out.println("Bye!");
		System.exit(0);
	}

	public static void finished(){
		//put s into the user_history file
		try{
			File f=new File("user_history.txt");
			fw=new FileWriter(f,true);
			pw=new PrintWriter(fw);
			pw.println(s);
			pw.close();
		}catch(Exception exc){System.out.println(exc);}
		his.addNode(s,0);
		//System.out.println("Word "+s+" added into the history");
		return;
	}
	
	public static void finished(int n){

		System.out.println("WORD COMPLETED: "+str_a[n]);
		s=str_a[n];
		return;
	}

	public static String[] search(char ch){
		String[] result=new String[5];
		long time1=System.nanoTime();//time initial
		int num;
		//need to  into the user history first;
		String[] s_h;//for user history
		String[] temp= new String[5];//for dictionary

		if (his_p!=null) {
			his_p=his_p.sub_nodes(ch);
		}
		if (his_p!=null){
			s_h=his_p.find_word(ch);
		}else {
			s_h=null;
		}

		if (dict_p!=null || s_h!=null){//able to search

			if (dict_p!=null) {
				temp=dict_p.find_word(ch,5);
				for (int i=0;i<5 ;i++ ) {
					temp[i]=s+temp[i];
					// System.out.println(temp[i].equals(s));
				}
			} 
			if(s_h!=null){
				int i_r=0;
				int i_h=0;
				int i_t=0;
				while (i_r<5){
					if (s_h[i_h]!=null && i_h<5){
						result[i_r++]=s_h[i_h++];

					} else{
						if (i_t<5 && temp[i_t]!=null  && !temp[i_t].equals(s)){
							boolean flag=true;
							for (int i=0;i<5 ;i++ ) {
								if (result[i]!=null && result[i].equals(temp[i_t])) {
									flag=false;
									break;
								}
							}
							if (flag){
								result[i_r++]=temp[i_t];
							}
							i_t++;
						} else{
							System.out.println("Did I return?");
							break;
						}
					}
				}
			
			} else{
				int j=0;
				for (int i=0;i<5 ;i++ ) {
					if (!temp[i].equals(s)){
						result[j]=temp[i];
						j++;
					}
				}
			}


			long time2=System.nanoTime();
			if (dict_p!=null) dict_p=dict_p.sub_nodes(ch);
			//output
			System.out.printf("[%.6fs]\n",(double)0.000001*(time2-time1));
			totaltime+=time2-time1;
			ct++;

			// System.out.println("result: ");
			// for (int i=0;i<5 ;i++ ) {
			// 	System.out.print(result[i]+ " ");
			// }
			// System.out.println();
			
			// if (s_h!=null){
			// 	System.out.println("history: ");
			// 	for (int i=0;i<5 ;i++ ) {
			// 		System.out.print(s_h[i]+ " ");
			// 	}
			// 	System.out.println();
			// } else {System.out.println("no history");}

			// System.out.println("dictionary: ");
			// for (int i=0;i<5 ;i++ ) {
			// 	System.out.print(temp[i]+ " ");
			// }
			// System.out.println();

			System.out.println("predictions:");
			int i=1;boolean nw=false;
			while (i<6 && result[i-1]!=null ) {
				System.out.print("("+i+")"+result[i-1]+"    ");
				i++;
				nw=true;
			}
			System.out.println();
			s+=ch;
			if (!nw) {System.out.println("WARNING: word does not exist");}
			return result;


		} else{//new word
			s+=ch;
			System.out.println("WARNING: word does not exist");//need to be modified
			return null;
		}
	}

	public static void processing(char input){
		//the main program part
		boolean bool=true;
		while (bool){
			switch (input) {
				case '!':quit();
						 break;
				case '1':
				case '2':
				case '3':
				case '4':
				case '5':finished(input-'1');
				case '$':finished();
						 return;
				default:str_a=search(input);
			}
			
			System.out.print("Enter the next character:");
			input=sc.next().charAt(0);
		}
		return;
	}	

	public static void main(String[] args) {
		creation();
		char input;

		boolean ending=false;
		do {
			s="";
			dict_p=dict;
			his_p=his;
			System.out.print("Enter your first character:");
			input=sc.next().charAt(0);
			//s+=input;
			processing(input);
		}while(!ending);
		
	}

	

}