public class DLBnode_his{//modified dlb trie for user_history file
	//data types
	private char value;
	private int count=0;
	private DLBnode_his next=null;
	private DLBnode_his child=null;
	private int[] mx5v=new int[5];
	private String[] mx5s=new String[5];
	//constructor
	public DLBnode_his(){
		value=0;
	}
	public DLBnode_his(char ch){
		value=ch;
		//count++;
	}

	public int addNode(String str,int n){// return: modified new number of nodes; -1 means no midify 
		if (n> str.length()) return this.count;
		char ch;
		if (n==str.length()) {
			ch='^';
		} else{
			ch=str.charAt(n);
		}
		
		//this.count++; // adding its subnodes
		DLBnode_his temp=this.child;//the place where saves the updated-node
		DLBnode_his tmp;
		if (temp!=null){ //does have at least a child before
			while (temp.value!=ch){
				if (temp.next!=null){
					temp=temp.next;
				} else {// ch is never in the list before
					tmp=new DLBnode_his(ch);
					temp.next=tmp;
					temp=tmp;
					break;
				}
			}
			//temp.count++// now at the correct position
		} else{//does not have a child before
			temp=new DLBnode_his(ch);
			this.child=temp;
			//temp.count++;
		}
			temp.count++;
			//System.out.println(str+" has "+temp.count+" times");
		if (str.length()<n){
			return this.count;
		// if (str.length()==n){//base case
		// 	return temp.count;// return new number of words;
		} else {
			//recursive 
		// if (str.length()>n){
			int update=temp.addNode(str,n+1);
			if (update<0){//null means did not change the max frequency
				return -1;
			} else{// changed before
				if (n==0){
					//System.out.println("ccccccccc"+temp.value);

				}
				boolean boo=false;
				for (int i=0;i<5 ;i++ ) {
					if (str.equals(mx5s[i])){
						mx5v[i]++;
						//System.out.println("Update string "+str+ " at node " +temp.value+" with value "+mx5v[i]+" ");
						boo=true;
						return update;
					}
					//System.out.println();
				} 
				if (!boo){
					for (int i=0;i<5 ;i++ ) {
						//System.out.println(temp.value+" "+mx5v[i]+"vs"+update+"@"+i);

						if (mx5v[i]<update){// has to change the frequency
							//System.out.println(temp.value);
							mx5v[i]=update;
							mx5s[i]=str;
							//System.out.println("add "+mx5s[i]+" at node "+temp.value+" with time"+mx5v[i]);
							return update;
						}
					}
				}
			//did not change the frequency
			return -1;
			} 
		}
	}

	public String[] sort(DLBnode_his node){
		int value;
		String s;
		for (int i=0;i<5 ;i++ ) {
			for (int j=1;j<5-i ;j++ ) {
				if (node.mx5v[j-1]<node.mx5v[j]){
					  value = node.mx5v[j-1];
					  s=node.mx5s[j-1];  
					  node.mx5v[j-1]=node.mx5v[j];
					  node.mx5s[j-1]=node.mx5s[j];
					  node.mx5v[j]=value;
					  node.mx5s[j]=s;
				}
			}
		}
		return node.mx5s;
	}

	public String[] find_word(char ch){
		//System.out.println("find words: ");
		DLBnode_his node=this;//.sub_nodes(ch);
		if (node==null) {
			return null;
		}else {//Sorting and output
			String[] str=new String[5];
			
			// for (int i=0;i<5 ;i++ ) {
			// 	System.out.println(node.mx5s[i]);	
			// }
			str=sort(node);
			return str;
		}
	}

	public DLBnode_his sub_nodes(char ch){
		if (this.child==null) return null;
		DLBnode_his node=this.child;
		
		while (node.value!=ch){
			if (node.next!=null){
				node=node.next;
			} 
			else {return null;}
		}
		return node;
	}

	public char get_value(){
		return value;
	}

	public DLBnode_his get_next(){
		return next;
	}

	public DLBnode_his get_child(){
		return child;
	}

}