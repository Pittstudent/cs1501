import java.*;
import java.lang.*;
import java.io.*;
import java.util.*;
public class test {
	static String[] str=new String[10];
	// static DLBnode root=new DLBnode();
	static DLBnode_his root=new DLBnode_his();
	static String[] str_a;
	static Scanner sc=new Scanner(System.in);
	public static void test_add(){
		//test for DLB node adding
		str[0]="alpha";
    	str[1]="app";
		str[2]="bear";
		str[3]="apple";
		str[4]="app";
		str[5]="alp";
		str[6]="to";
		str[7]="too";
		str[8]="too";
		str[9]="to";

		for (int i=0;i<10 ;i++ ) {	
			int j=root.addNode(str[i],0);
			//System.out.println(j);		
		}

		String[] temp;//=root.find_word('t');
		temp=root.sub_nodes('a').sub_nodes('l').sub_nodes('p').sub_nodes('h').find_word('a');
		temp=root.sub_nodes('a').sub_nodes('l').sub_nodes('p').find_word('h');
		temp=root.sub_nodes('a').sub_nodes('l').find_word('p');
		temp=root.sub_nodes('a').find_word('l');
		temp=root.find_word('a');



	    //temp=root.sub_nodes('t').sub_nodes('o').find_word('o');

		//System.out.println(root.get_child().get_next().get_next().get_value());
		for (int i=0;i<5 ;i++ ) {
		//	System.out.println(root.get_child().get_next().get_next().mx5v[i]);
			//System.out.println(root.mx5v[i]);

			//System.out.println(root.mx5s[i]);


		}
	}
	
	public static void add_dict(){
		try{
			File file=new File("dictionary.txt");
			Scanner sc_f=new Scanner(file);
			if(!file.exists()){//file not exist
		        System.out.print("Dictionary File does not exist. ");
	            System.exit(0);
	        }
	        while(sc_f.hasNextLine()){
		        String str=sc_f.nextLine();
		        int j=root.addNode(str,0);
	        }
	        sc_f.close();
		}catch(Exception exc){System.out.println(exc);}
	}

	// public static void test_subnodes(){
	// 	//DLBnode subnode= root.sub_nodes('m');
	// 	//System.out.println(subnode.get_value());
	// 	//System.out.println(subnode.get_next().get_value());
	// 	String[] str=root.find_word('m',5);
	// 	System.out.println(str.length);
	// 	for (int i=0;i<5 ;i++) {
	// 		System.out.println(str[i]);
	// 	}
	// }

	// public static void test_findword(){
	// 	String[] str=root.find_word('M',5);
	// 	System.out.println(str.length);
	// 	for (int i=0;i<5 ;i++) {
	// 		System.out.println(str[i]);
	// 	}
	// }

	public static void main(String[] args) {
		test_add();
		//System.out.println(root.get_child().get_next().get_value());
		// add_dict();
		// System.out.println(root.sub_nodes('A').get_next().get_value());
		// test_subnodes();
		// test_findword();
	}
}