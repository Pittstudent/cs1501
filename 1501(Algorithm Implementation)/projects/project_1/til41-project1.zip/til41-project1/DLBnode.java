import java.util.*;
public class DLBnode {
	
	//private DLBnode root;
	private char value;
	private boolean word=false;
	private DLBnode next=null;
	private DLBnode child=null;

	public DLBnode(){
		value=0;
	}
	public DLBnode(char ch){
		value=ch;
	}


	public void addNode(String str){//O(l) process
		char[] ch_a=str.toCharArray();
		DLBnode pointer=this.child;
		DLBnode tmp;
		DLBnode parent=this;
		for (int i=0;i<ch_a.length;i++){//add each ch
			char ch=ch_a[i];
			if (pointer==null){ //does not contain any child at this level
				pointer = new DLBnode(ch); 
				parent.child = pointer;
				//System.out.println("Node "+ch+" added");
			} else {//has child
				while (ch!= pointer.value){//the child is not the same character
					//System.out.println("vist node "+pointer.value);				
					if (pointer.next!=null){//has next
						pointer=pointer.next;//
					} else {
						DLBnode temp=new DLBnode(ch);
						pointer.next=temp;//add it to the next trees
						pointer=temp;
						//System.out.println("Node "+ch+" added");
					}
				}
				//now at the same character place
				//System.out.println("at character "+pointer.value);
			}
			if (ch_a.length==(i+1)){//word finished
				pointer.set_word(true);
				//System.out.println(pointer.word);
			} else {//word not finished
				//System.out.println(pointer.word);
				parent=pointer;
				pointer=pointer.child;
			}
		}
	}

	public String[] find_word(char ch, int num){//basically pre-order traversal
		//initialization
		String[] str=new String[num];
		for (int i=0;i<num ;i++ ) {
			str[i]="";
		}

		Stack<DLBnode> stack=new Stack<DLBnode>();
		int i=0;
		DLBnode node=this.sub_nodes(ch);
		if (node==null) return str;
		do{	//in order t
			while (node!=null){//vist left
				stack.push(node);
				str[i]+=node.value;
				if (node.end_word()){
					i++;
					if (i==num) return str;
					str[i]=str[i-1];//copy string
				}
				node=node.get_child();
			}

			if (!stack.isEmpty()){
				DLBnode tmp=stack.pop();
				str[i]=str[i].substring(0,str[i].length()-1);//going up to its previous location
				node=tmp.get_next();
				//System.out.println("turns to node:" +node.get_value());
			}
		}while (!stack.isEmpty() || node!=null);
		
		return str;
	}

	public DLBnode sub_nodes(char ch){//first we assume more than 5 options avaliable
		if (this==null) return null;
		if (this.child==null) return null;
		DLBnode node=this.child;

		while (node.value!=ch) {
			if (node.next!=null){node=node.next;} 
			else {return null;}
			//if (node==null) return null;
		}
		return node;
	}

	public char get_value(){
		return value;
	}

	public DLBnode get_next(){
		return next;
	}

	public DLBnode get_child(){
		return child;
	}

	public void set_word(boolean bool){
		word=bool;
	}

	public boolean end_word(){
		return word;
	}

}
