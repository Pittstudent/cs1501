import java.util.*;
import java.lang.*;
import java.util.Random;
import java.util.Arrays;


public class AptTracker{

	static Scanner sc=new Scanner(System.in);
	//data
	static Apt[] apts=new Apt[100];//apartment list data
	static City[] cityInfo=new City[100];//value: city index

	//index mappings
	static int[] map=new int[100];//index-> hash apt value 
	static int[] mapc=new int[100];//index-> hash city value 
	static int[] minPQ=new int[100];//binary map order-> index //rev
	static int[] maxPQ=new int[100];//order -> index
	
	//reverse funtions: note
	static Hnode[] re_map=new Hnode[200];//hash apt->index
	static Hnode[] re_ct=new Hnode[200];//hash city->index
	static int[] re_min=new int[100];//index-> order
	static int[] re_max=new int[100];//index->order


	//global parameters
	static int lva=0;//level for hash map apartment
	static int lvc=0;//level for hash map city
	static int counter=0;
	static int counterc=0;
	static int order;
	static boolean stop=false;
	static int R=256;
	static int q=179;

	static class Hnode{//hash nodes
		int val=0;
		//int rev;
		Hnode next;
		Hnode(int h){
			val=h;
		}
	}
	//help functions
	public static int readInt(){
		boolean boo=false;
		while (!boo){
			if (sc.hasNextInt()){
				boo=true;
			} else {
				String garbage=sc.next();
				System.out.println("Invalid input, please enter a number");
			}
		}
		return sc.nextInt();
	}

	public static boolean isPrime(int n) {
	    if(n%2 == 0 || n%3 == 0) return false;
	    int sqrtN = (int)Math.sqrt(n)+1;
	    for(int i = 6; i <= sqrtN; i += 6) {
	        if(n%(i-1) == 0 || n%(i+1) == 0) return false;
	    }
	    return true;
	}

	public static void init(){
		Arrays.fill(map,-1);
		Arrays.fill(mapc,-1);
		Arrays.fill(minPQ,-1);
		Arrays.fill(maxPQ,-1);
		Arrays.fill(re_max,-1);
		Arrays.fill(re_min,-1);
	}

	public static Apt[] resize(Apt[] aps){
		Apt[] new_apts= new Apt[2*apts.length];
		for (int i=0;i<apts.length;i++) {
			new_apts[i]=apts[i];
		}
		//resize_hash();
		return new_apts;
	}

	public static int[] resize(int[] arr){
		int[] new_arr= new int[2*arr.length];
		Arrays.fill(new_arr,-1);
		for (int i=0;i<arr.length;i++) {
			new_arr[i]=arr[i];
		}
		//resize_hash();
		return new_arr;
	}

	public static void resize(){
		apts=resize(apts);
		map=resize(map);
		mapc=resize(mapc);
		minPQ=resize(minPQ);
		maxPQ=resize(maxPQ);
		re_min=resize(re_min);
		re_max=resize(re_max);
	}

	//hash functions
	public static void add_hash(Hnode[] hm, int h, Hnode node,int lv){
		int ct=0;
		Hnode tmp=hm[h];
		if (tmp==null){
			hm[h]=node;
			//System.out.println("adding to re_map:"+h+"for index "+hm[h].val);
		} else {
			while (tmp.next!=null){
				tmp=tmp.next;
				ct++;
			}
			tmp.next=node;
		}
		if (ct>lv) lv=ct;
		if (lv>10) resize_hash(hm,lv);
	}

	public static int find_hash(Hnode[] hm, int h,String s, int n,int zip){
		Hnode node=hm[h];
		if (node==null) return -1;
		int ind=node.val;
		while(!same(apts[ind],s,n,zip)){
			node=node.next;
			if (node==null) return -1;
		}
		return ind;
	}

	public static int hash(String s,int n1,int n2){ //map apartment -> hash value
		//System.out.println("address: "+s+"number "+n1+"zip "+n2);
		int h=0;
		for (int j = 0; j < s.length(); j++) 
            h = (R * h + s.charAt(j)) % q;
        h= R*h*n1 % q;
        h= R*h*n2 % q;
        //System.out.println("Hash value: "+h);
        return h;
	}

	public static int hash(String s){ //map city<-> hash map; hash map<->index
		int h=0;
		for (int j = 0; j < s.length(); j++) 
            h = (R * h + s.charAt(j) ) % q;
        return h;
	}



	public static void resize_hash(Hnode[] hm,int lv){
		//Hnode[] resize_hm=new Hnode[2*q+1];
		for (int i=q;i<2*q;i++) {
			if(isPrime(i)) {//Bertrand's postulate guarantees exist
				q=i;
				break;
			}
		}
		if (hm.equals(re_map)){//apts
			lva=0;
			re_map=new Hnode[2*q+1];
			for (int i=0;i<=order;i++){
				if (apts[i]!=null){
					Hnode node=new Hnode(i);
					String s=apts[i].get_address();
					int num=apts[i].get_num();
					int zip=apts[i].get_zip();
					int h=hash(s,num,zip);
					map[i]=h;
					add_hash(re_map,h,node,lva);
				}
			}
		} else if (hm.equals(re_ct)){
			lvc=0;
			re_ct=new Hnode[2*q+1];
			for (int i=0;i<=counterc;i++){
				if (cityInfo[i]!=null){
					Hnode node=new Hnode(i);
					String s=cityInfo[i].get_name();
					int h=hash(s);
					mapc[i]=h;
					add_hash(re_ct,h,node,lvc);
				}
			}
		}

	}


	public static void remove_hash(int hash_delete,int hash_change,int delete,int change){
		//System.out.println("delete"+delete);
		Hnode node1=re_map[hash_delete];
		Hnode node2=null;
		if (hash_change!=-1) node2=re_map[hash_change];
		Hnode temp=re_map[hash_delete];
		if (node1==null) {
			System.out.println("remove hashing error");
		}
		if (node1.next==null){
			re_map[hash_delete]=null;
		}

		while (node1!=null){//delete
			int h1=node1.val;
			if (h1==delete){
				if (node1.next!=null) {
					temp.next=node1.next;
				} else{
					temp.next=null;
				}
				node1=null;
			}else{
				temp=node1;
				node1=node1.next;
			}
		}

		while (node2!=null){
			int h2=node2.val;
			if (h2==change){
				node2.val=delete;
				break;
			}
		}

		return;
	}

	
	public static boolean same(Apt apt,String ad,int num,int zip){
		if (apt==null) return false;
		String s=apt.get_address();
		int n1=apt.get_num();
		int n2=apt.get_zip();
		if (n1!=num) return false;
		if (n2!=zip) return false;
		if (!ad.equals(s)) return false;
		return true;
	}

	//maintain heap proporties
	public static boolean need_swap(int p, int ch, boolean flag){
		if (flag){//max heap
			if (maxPQ[ch]<0||maxPQ[p]<0) return false; 
			System.out.println("P: "+p+"Ch: "+ch);
			System.out.println("maxPQ[ch]"+maxPQ[ch]+"maxPQ[p]"+maxPQ[p]);

			System.out.println("parent: "+apts[maxPQ[p]].get_size()+"child: "+apts[maxPQ[ch]].get_size());
			return apts[maxPQ[p]].get_size()<apts[maxPQ[ch]].get_size();
		} else {//min heap

			if (minPQ[ch]<0||minPQ[p]<0) return false; 
			System.out.println("parent: "+apts[minPQ[p]].get_price()+"child: "+apts[minPQ[ch]].get_price());
			return apts[minPQ[p]].get_price()>apts[minPQ[ch]].get_price();
		}
	}

	public static void swap(int[] index, int[] rev, int i, int j){
		//printIntArr(index);
		//System.out.println("counter: "+i+" index2: "+j);
		int temp=index[i];
		//System.out.println("maxPQ old counter: "+temp+" maxPQ index2: "+index[j]);
		index[i]=index[j];
		index[j]=temp;
		printIntArr(index);
		//System.out.println("now indexi"+index[i]+"now indexj"+index[j]);
		rev[index[i]]=i;
		rev[index[j]]=j;
		//printPQ();
		return;
	}

	public static void swim(int[] index, int[] rev, int n, boolean flag){//build the heap

		while (n>1 && need_swap(n/2,n,flag)){
			swap(index,rev,n,n/2);
			n=n/2;
		}
		return;
	}


	public static void sink(int n,boolean flag){
		while (n*2<=counter){
			//System.out.println("sink");
			int l=2*n;
			//System.out.println("l"+l+"n"+n);
			if (flag){
				if (l< counter && need_swap(l,l+1,flag))l++;
				if (!need_swap(n,l,flag)) break;
				swap(maxPQ,re_max,n,l);
			} else{
				if (l< counter && need_swap(l,l+1,flag))l++;
				if (!need_swap(n,l,flag)) break;
				swap(minPQ,re_min,n,l);
			}
			n=l;
		}
	}

	//heap operations
	public static void insert(int[] index, int[] rev, int n, Apt apt, boolean flag){//flag:0 min 1 max
		if (apts.length<=n) resize();
		apts[n]=apt;
		swim(index,rev,counter,flag);
		return;
	}

	public static int find(){//return the index of data for the apt
		System.out.println("please enter the street address:");
		sc.nextLine();
		String s1=sc.nextLine();
		System.out.println("please enter the apartment number:");
		int n1=readInt();
		System.out.println("please enter the zip code:");
		int n=readInt();
		int temp=hash(s1,n1,n);
		int ind=find_hash(re_map,temp,s1,n1,n);

		return ind;

	}

	public static int findC(String s){//return the index of the city
		if (s==null) return -1;
		if (counterc<1) return -1;
		int i=hash(s);
		Hnode tmp=re_ct[i];
		if (tmp==null) return -1;
		int ind=tmp.val;
		boolean flag=false;
			
		while(tmp!=null){
			City temp=cityInfo[ind];
			flag=s.equals(temp.get_name());
			if (!flag){
				tmp=tmp.next;
				if (tmp==null) return -1;
				ind=tmp.val;
			} else {
				return ind;
			}
		}
		return -1;
	}

	//main function operatiions 
	public static void add(){//1
		order++;
		counter++;
		if (!(apts.length>order)) resize();
		System.out.println("Adding apartment:\n");
		//basic info
		//System.out.println("____________________________________________");
		System.out.println("please enter the street address: ");
		sc.nextLine();
		String s1=sc.nextLine();
		System.out.println("please enter the apartment number:");
		int n1=readInt();
		System.out.println("please enter the city name:");
		String s2=sc.nextLine();
		s2=sc.nextLine();
		System.out.println("please enter the zip code:");
		int n=readInt();
		Apt node=new Apt(s1,s2,n1,n);
		System.out.println("please enter the price to rent ($/mo):");
		int n2=readInt();
		node.update_price(n2);
		System.out.println("please enter the square footage of the apartment:");
		n2=readInt();
		//System.out.println("____________________________________________\n")
		node.update_size(n2);
		apts[order]=node;

		//hash maps
		int h=hash(s1,n1,n);
		Hnode hnode=new Hnode(order);
		map[order]=h;
		add_hash(re_map,h,hnode,lva);

		//insert to the heaps
		minPQ[counter]=order;
		maxPQ[counter]=order;
		re_min[order]=counter;
		re_max[order]=counter;
		insert(minPQ,re_min,order,node,false);//min price PQ
		insert(maxPQ,re_max,order,node,true);//max size PQ
		//find the city need to be inserted
		n=findC(s2);
		City temp;
		if (n<0) {
			temp=new City(s2);
			System.out.println("city "+s2+" created!");
			cityInfo[counterc]=temp;
			h=hash(s2);
			hnode=new Hnode(counterc);
			mapc[counterc]=h;
			add_hash(re_ct,h,hnode,lvc);
			counterc++;
		} else{
			temp=cityInfo[n];
		}
		//add to the city
		temp.add(node,order);		


		return;
	}

	public static void update(){//2

		System.out.println("Updating apartment:\n");
		//basic info
		int i=find();//find the apartment need to be updated
		if (i<0){
			System.out.println("the apartment does not exist!");
			return;
		}
		Apt node=apts[i];
		String s=node.get_city();
		int j=findC(s);
		System.out.println("the old price was "+node.get_price());
		System.out.println("please enter the price to rent ($/mo):");
		int n=readInt();
		node.update_price(n);
		System.out.println("the old size was "+node.get_size());
		System.out.println("please enter the square footage of the apartment:");
		n=readInt();
		node.update_size(n);

		//update the heaps
		swim(minPQ,re_min,re_min[i],false);
		sink(re_min[i],false);
		swim(maxPQ,re_max,re_max[i],true);
		sink(re_max[i],true);
		//update the city heaps
		City c=cityInfo[j];
		c.update(i);
		return;
	}


	public static void printPQ(){
		// System.out.println("minPQ");
		// for (int i=1;i<=counter ;i++ ) {
		// 	apts[minPQ[i]].print();
		// }
		System.out.println("maxPQ");
		for (int i=1;i<=counter ;i++ ) {
			apts[maxPQ[i]].print();
		}
	}

	public static void printIntArr(int[] arr){
		for (int i=0;i<7;i++ ) {
			System.out.print(arr[i]+" ");
		}
		System.out.println();
	}
	public static void remove(){//3 remove a 
		System.out.println("Removing apartment:\n");
		int i=find();
		if (i<0) {
			System.out.println("apartment does not exist!");
			return;
		}
		Apt node=apts[i];
		//apts[i].print();

		//remove from the city
		String s=node.get_city();
		int j=findC(s); 
		City c=cityInfo[j];
		c.remove(i);
		//remove (and update) from the hash table;
		//System.out.println(i+"hash value"+map[i]);
		int h1=map[i];
		int h2=map[counter];
		remove_hash(h1,h2,i,counter);
		//remove from the heap
		System.out.println("WTF");
		System.out.println(i);
		System.out.println(maxPQ[re_max[i]]);
		int index1=re_min[i];
		int index2=re_max[i];
		System.out.println(index2);
		//apts[re_max[index2]].print();
		//apts[maxPQ[counter]].print();

		swap(minPQ,re_min,counter,index1);
		System.out.println("before swap: counter "+counter+" index2 "+index2);
		swap(maxPQ,re_max,counter,index2);
		apts[maxPQ[index2]].print();
		//apts[maxPQ[counter]].print();
		counter--;
		// System.out.println(re_min[i]);
			//printPQ();
		swim(minPQ,re_min,index1,false);
		sink(index1,false);
		// System.out.println("maxxxxx");
		swim(maxPQ,re_max,index2,true);
		sink(index2,true);
		//printPQ();
		//remove from the list
		
		 apts[i]=null;
		 re_min[i]=-1;
		 re_max[i]=-1;
		 minPQ[counter+1]=-1;
		 maxPQ[counter+1]=-1;

	}
	
	public static void cheapest(){//4
		System.out.println("Finding cheapest apartment:\n");
		if (minPQ[1]<0) {
			System.out.println("No apartment avaliable!");
			return;
		}
		Apt node= apts[minPQ[1]];
		if (node==null){
			System.out.println("No apartment avaliable!");
			return;
		}
		node.print();
		return;
	}

	public static void largest(){//5
		System.out.println("Finding largest apartment:\n");
		if (minPQ[1]<0) {
			System.out.println("No apartment avaliable!");
			return;
		}
		Apt node= apts[maxPQ[1]];
		if (node==null){
			System.out.println("No apartment avaliable!");
			return;
		}
		node.print();
		return;
	}

	public static void cheapc(){//6
		System.out.println("Finding cheapest apartment in a city:\n");

		System.out.println("please enter the city name");
		sc.nextLine();
		String input=sc.nextLine();
		int i=findC(input);
		if (i<0) {
			System.out.println("There is no apartment avaliable in "+input);
			return;
		}
				System.out.println("Can find the city");

		City c=cityInfo[i];
		if (c==null) {
			System.out.println("There is no apartment avaliable in "+input);
			return;
		}
		Apt a=c.cheapest();
		if (a==null) {
			System.out.println("There is no apartment avaliable in "+input);
			return;
		}
		a.print();
		return;
	}

	public static void largec(){//7
		System.out.println("Finding largest apartment in a city:\n");

		System.out.println("please enter the city name");
		sc.nextLine();
		String input=sc.nextLine();
		int i=findC(input);
		if (i<0) {
			System.out.println("There is no apartment avaliable in "+input);
			return;
		}
		City c=cityInfo[i];
		if (c==null) {
			System.out.println("There is no apartment avaliable in "+input);
			return;
		}
		Apt a=c.largest();
		if (a==null) {
			System.out.println("There is no apartment avaliable in "+input);
			return;
		}
		a.print();
		return;
	}


	public static void main(String[] args) {//menu based program
		init();
		stop=false;
		while(!stop){
			System.out.println("____________________________________________\n");
			System.out.println("What would you like to do?(enter number 0-7)\n");
			System.out.println("1.Add an apartment\n");
			System.out.println("2.Update an apartment\n");
			System.out.println("3.Remove a specific apartment \n");
			System.out.println("4.Retrieve the lowest price apartment\n");
			System.out.println("5.Retrieve the highest square footage apartment\n");
			System.out.println("6.Retrieve the lowest price apartment by city\n");
			System.out.println("7.Retrieve the highest square footage apartment by city\n");
			System.out.println("0.Exit the program");
			System.out.println("____________________________________________\n");
		
			int input=readInt();
			switch (input) {
				case 1: add();
						break;
				case 2: update();
						break;
				case 3: remove();
						break;
				case 4: cheapest();
						break;
				case 5: largest();
						break;
				case 6: cheapc();
						break;
				case 7: largec();
						break;
				case 0: stop=true;
						break;
				//case 8: printPQ();
				//		break;
				default: System.out.println("Invalid input, please try again!\n");
			}
		}

		System.out.println("Thanks for using the app");
		System.exit(0);

	}
}