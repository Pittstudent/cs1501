import java.util.Arrays;

public class City{
	String name;
	Apt[] apts=new Apt[100];
	int[] priceHeap=new int[100];//index
	int[] sizeHeap=new int[100];//index
	int[] re_min=new int[100];//rev 
	int[] re_max=new int[100];//rev
	int[] ref=new int[100];//record n
	int[] re_ref=new int[100];//reverse of recording n
	int counter=0;
	int order=0;
	//constructor

	public City(){
		Arrays.fill(re_ref,-1);
	}
	public City(String s){
		name=s;
		Arrays.fill(re_ref,-1);
	}
	
	//operation
	public void resize(int[] arr){
		int[] new_arr=new int[2*arr.length];
		Arrays.fill(new_arr,-1);
		for (int i=0;i<arr.length;i++ ) {
			new_arr[i]=arr[i];
		}

	}

	public void resize1(int n){
		int[] arr=new int[2*n];
		Arrays.fill(arr,-1);
		for (int i=0;i<re_ref.length;i++ ) {
			arr[i]=re_ref[i];
		}
		//return arr;
	}
	//calling function
	public String get_name(){
		return name;
	}

	public Apt cheapest(){
		if (priceHeap[1]<0) return null;
		return apts[priceHeap[1]];
	}

	public Apt largest(){
		if (sizeHeap[1]<0) return null;
		return apts[sizeHeap[1]];
	}

	public  boolean need_swap(int p, int ch, boolean flag){
		if (flag){//max heap
			return apts[sizeHeap[p]].get_size()<apts[sizeHeap[ch]].get_size();
		} else {//min heap
			return apts[priceHeap[p]].get_price()>apts[priceHeap[ch]].get_price();
		}
	}

	public void swap(int[] index, int[] rev, int i, int j){
		int temp=index[i];
		index[i]=index[j];
		index[j]=temp;
		rev[index[i]]=i;
		rev[index[j]]=j;
		return;
	}

	
	
	public void update(int n){
		int i=re_ref[n];
		System.out.println(n+" "+i);
		swim(priceHeap,re_min,i,false);
		sink(i,false);
		swim(sizeHeap,re_max,i,true);
		sink(i,true);
	}

	public void remove(int n){
		int i=re_ref[n];
		System.out.println("n "+n+" i "+i);
		int index1=re_min[i];
		int index2=re_max[i];
		swap(priceHeap,re_min,re_min[counter],index1);
		swap(sizeHeap,re_max,re_max[counter],index2);
		counter--;
		swim(priceHeap,re_min,index1,false);
		sink(index1,false);
		swim(sizeHeap,re_max,index2,true);
		sink(index2,true);
		apts[i]=null;
		re_max[i]=-1;
		re_min[i]=-1;
		//priceHeap[counter+1]=-1;
		//sizeHeap[counter+1]=-1;
	}

	public  void swim(int[] index, int[] rev, int n, boolean flag){//build the heap
		while (n>1 && need_swap(n/2,n,flag)){
			swap(index,rev,n,n/2);
			n=n/2;
		}
		return;
	}

	// public  boolean need_swap(int p, int ch, boolean flag){
	// 	if (flag){//max heap
	// 		if (sizeHeap[ch]<0||sizeHeap[p]<0) return false; 
	// 		System.out.println("parent: "+apts[sizeHeap[p]].get_size()+"child: "+apts[sizeHeap[ch]].get_size());
	// 		return apts[sizeHeap[p]].get_size()<apts[sizeHeap[ch]].get_size();
	// 	} else {//min heap
	// 		if (priceHeap[ch]<0||priceHeap[p]<0) return false; 
	// 		System.out.println("parent: "+apts[priceHeap[p]].get_price()+"child: "+apts[priceHeap[ch]].get_price());
	// 		return apts[priceHeap[p]].get_price()>apts[priceHeap[ch]].get_price();
	// 	}
	// }


	public  void sink(int n,boolean flag){
		while (n*2<=counter){
			int l=2*n;
			if (flag){
				if (l< counter && need_swap(l,l+1,flag))l++;
				if (!need_swap(n,l,flag)) break;
				swap(sizeHeap,re_max,n,l);
			} else{
				if (l< counter && need_swap(l,l+1,flag))l++;
				if (!need_swap(n,l,flag)) break;
				swap(priceHeap,re_min,n,l);
			}
			n=l;
		}
	}

	public void insert(int[] index,int[] rev, int n,Apt apt, boolean flag){
		//if (apts.length<=counter) resize(apts);
		apts[n]=apt;
		swim(index,rev,counter,flag);
	}

	public void add(Apt node,int n){
		order++;
		counter++;
		priceHeap[counter]=order;
		sizeHeap[counter]=order;
		re_min[order]=counter;
		re_max[order]=counter;
		insert(priceHeap,re_min,order,node,false);//min price PQ
		insert(sizeHeap,re_max,order,node,true);//max size PQ
		ref[order]=n;
		re_ref[n]=order;
		System.out.println("adding "+ re_ref[n]+" "+order);
		
	}


}