public class Apt{
	private String address;
	private int number;
	private String city;
	private int zip;
	private int price;
	private int size;
	
	public Apt(){
		
	}
	public Apt(String add, String cit, int num1,int num2){
		address=add;
		city=cit;
		number=num1;
		zip=num2;
	}


	public void update_price(int n){
		price=n;
	}

	public void update_size(int n){
		size=n;
	} 

	public String get_address(){
		return address;
	}

	public String get_city(){
		return city;
	}

	public int get_num(){
		return number;
	}

	public int get_zip(){
		return zip;
	}

	public int get_price(){
		return price;
	}

	public int get_size(){
		return size;
	}


	public void print(){
		System.out.println("____________________________________________");
		System.out.println("Here is the info of the Apartment:");
		System.out.println("Apartment address: "+address);
		System.out.println("Apartment number: "+number);
		System.out.println("City: "+city);
		System.out.println("Zip code: "+zip);
		System.out.println("Price($/Mo): "+price);
		System.out.println("Size(in squarefeet): "+size);
		System.out.println("____________________________________________");

	}
}