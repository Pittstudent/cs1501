import java.lang.*;
import java.io.*;
import java.util.*;
public class NetworkAnalysis {
	static Scanner sc = new Scanner(System.in);
	static Network net;
	static int numv;
	static FlowNetwork flownet;
	static EdgeWeightedDigraph g1;
	static EdgeWeightedGraph g2;

	public static void init(String s){
		try{
			String f_name=s;
			File file=new File(f_name);
			boolean f_ex=file.exists();
			while(!f_ex){
				 System.out.print("File does not exist. Please type the name of question file>>");
	             f_name=sc.nextLine();
	             file=new File(f_name);
	             f_ex=file.exists();
			}
			Scanner sc_f=new Scanner(file);
			String tmp=sc_f.nextLine();
			numv=Integer.parseInt(tmp);
			flownet=new FlowNetwork(numv);
			g1=new EdgeWeightedDigraph(numv);
			g2=new EdgeWeightedGraph(numv);
			net=new Network(numv);
			while (sc_f.hasNext()){
				tmp=sc_f.nextLine();
				String[] temp=tmp.split(" ");
				int v1=Integer.parseInt(temp[0]);
				int v2=Integer.parseInt(temp[1]);
				int type;
				switch (temp[2]) {
					case "optical": 
						type=0;
						break;
					case "copper": 
						type=1;
						break;
					default:
						System.out.println("Illegal Material!");
						type=-1;
						//return;
				}
				int cap=Integer.parseInt(temp[3]);
				int length=Integer.parseInt(temp[4]);
				//System.out.println(tmp);
				Edge e=new Edge(v1,v2,type,cap,length);
				net.add(e);
				System.out.println("edge "+tmp+" added!");
				FlowEdge flow_e=new FlowEdge(v1,v2,cap);
				DirectedEdge di_e=new DirectedEdge(v1,v2,e.time,cap);
				flownet.addEdge(flow_e);
				g1.addEdge(di_e);
				g2.addEdge(e);
				flow_e=new FlowEdge(v2,v1,cap);
				di_e=new DirectedEdge(v2,v1,e.time,cap);
				flownet.addEdge(flow_e);
				g1.addEdge(di_e);
				g2.addEdge(e);
			}
		}catch(Exception e){
			System.out.println(e);
		}
	}

	
	//helper functions
	public static int readInt(){
		boolean boo=false;
		while (!boo){
			if (sc.hasNextInt()){
				boo=true;
			} else {
				String garbage=sc.next();
				System.out.println("Invalid input, please enter a number");
			}
		}
		return sc.nextInt();
	}

	public static Edge minDist(boolean[] visit){
		int[] in=new int[numv];
		int[] out=new int[numv];
		int counter1=0;
		int counter2=0;
		for (int i=0;i<numv;i++) {
			if (visit[i]){
				in[counter1]=i;
				counter1++;
			} else {
				out[counter2]=i;
				counter2++;
			}
		} 
		//find min time between 2 sets
		Edge added=null;
		for (int i=0;i<counter1;i++) {
			double min=-1;
			for (int j=0;j<counter2;j++) {
				double val=-1;
				Edge tmp=net.find(in[i],out[j]);
				if (tmp!=null) {
					val=tmp.time;
					//tmp.print();
				};
				if ((val>0) && ((min>val)||(min<0))) {
					min=val;
					added=tmp;
				}
			}
		}


		return added;
	}


	//main functions
	public static void llp(){//lowest latency path (prim)
		System.out.println("Please enter the start point");
		int v1=readInt();
		System.out.println("Please enter the end point");
		int v2=readInt();


		// double dist[]=new double[numv];
		// int fake_dist[]=new int[numv];
		// boolean visit[]=new boolean[numv];
		// int[] viav=new int[numv];

		// Arrays.fill(dist,Double.MAX_VALUE);
		// Arrays.fill(fake_dist,Integer.MAX_VALUE);
		// Arrays.fill(viav,-1);
		// Arrays.fill(visit,false);

		
		// visit[v1]=true;
		// dist[v1]=0;
		// double[] time=new double[numv];
		// for (int i=0;i<numv-1;i++) {
		// 	if (i==v1) continue;
		// 	Edge tmp=net.find(v1,i);
		// 	if (tmp!=null){
		// 		dist[i]=tmp.time;
		// 		System.out.println(i+" "+dist[i]);
		// 		viav[i]=v1;
		// 	}
		// }

		// for (int i=0;i<numv-1;i++) {
		// 	Edge e=minDist(visit);
		// 	System.out.println("Adding edge: ");
		// 			e.print();
		// 	int u2=e.getv2();
		// 	int u1=e.getv1();
		// 	int addv,pre_add;
		// 	if (!visit[u2]){
		// 		visit[u2]=true;
		// 		addv=u2;
		// 		pre_add=u1;
		// 	} else{
		// 		visit[u1]=true;
		// 		addv=u1;
		// 		pre_add=u2;
		// 	}
		// 	visit[addv]=true;
		// 	System.out.println("Vertex "+addv+" added");
		// 	dist[addv]=dist[pre_add]+e.time;
		// 	fake_dist[addv]=fake_dist[pre_add]+e.length;
		// 	viav[addv]=pre_add;
		// 	//update route
		// 	for (int j=0;j<numv;j++) {
		// 		if (!visit[j]) continue;
		// 		//if (addv==j) continue;
		// 		double distance=-1;
		// 		Edge tmp=net.find(j,addv);
		// 		if (tmp!=null) {
		// 			tmp.print();
		// 			distance=tmp.time+dist[addv];
		// 			int fake_distance=tmp.length+fake_dist[addv];
		// 			System.out.println(j+" "+addv);
		// 			//System.out.println("between "+j+" "+addv+"new "+distance+" old "+fake_dist[j]);
		// 			 System.out.print("Compare distance: ");
		// 			 System.out.printf("%5.2f ",distance);
		// 			 System.out.printf("%5.2f \n",dist[j]);
		// 		}
		// 		if (distance<0) distance=Double.MAX_VALUE;
				
		// 		if (visit[j] && distance<dist[j]){
		// 		System.out.print("new distance: ");
		// 		System.out.printf("%5.2f \n",distance);
		// 		System.out.print("old distance: ");
		// 		System.out.printf("%5.2f \n",dist[j]);
		// 			viav[j]=addv;
		// 			dist[j]=distance;
		// 		System.out.println(j+" new pre "+addv);
		// 		}
		// 	}
		// }
		// // for (int i=0;i<numv;i++ ) {
		// // 	System.out.print("" +viav[i]);
		// // } System.out.println();
		// for (int i=0;i<numv;i++ ) {
		// 	System.out.printf(" %.2f",dist[i]);
		// } System.out.println();
		DijkstraAllPairsSP d_all=new DijkstraAllPairsSP(g1);
		d_all.path(v1,v2);
	}

	public static void coc(){
		if (net.coc()) System.out.println("Is copper-only connected!");
		else System.out.println("Not copper-only connected!");
	}

	public static void max(){
		System.out.println("Please enter the start point");
		int s=readInt();
		System.out.println("Please enter the end point");
		int t=readInt();
		FordFulkerson ff=new FordFulkerson(flownet,s,t);
		double val=ff.value();
		System.out.println("the maximum flow would be "+ val);
		flownet.clear();
	}

	public static void lst(){
		PrimMST mst=new PrimMST(g2);
		System.out.println("The spannign tree looks like following");
		System.out.print(mst.edges());
		System.out.println("Done.");
	}

	public static void f2c(){

	}

	public static void main(String[] args) {
		boolean stop=false;
		init(args[0]);
		while(!stop){
			System.out.println("____________________________________________\n");
			System.out.println("What would you like to do?(enter number 0-5)\n");
			System.out.println("1.Find the lowest latency path\n");
			System.out.println("2.copper-only connected\n");
			System.out.println("3.maximum amount of data that can be transmitted\n");
			System.out.println("4.lowest average latency spanning tree\n");
			System.out.println("5.remain connected if any two vertices in the graph were to fail\n");
			System.out.println("0.Exit the program");
			System.out.println("____________________________________________\n");
		
			int input=readInt();
			switch (input) {
				case 1: llp();
						break;
				case 2: coc();
						break;
				case 3: max();
						break;
				case 4: lst();
						break;
				case 5: f2c();
						break;
				case 0: stop=true;
						break;
				case 8: net.print();
				//		break;
				default: System.out.println("Invalid input, please try again!\n");
			}
		}

		System.out.println("Thanks for using the app");
		System.exit(0);

	}
}