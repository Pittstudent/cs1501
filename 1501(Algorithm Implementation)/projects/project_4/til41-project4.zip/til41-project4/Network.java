import java.util.*;
public class Network{
	Edge[] a_list;
	public Network(int n){
		a_list=new Edge[n];
	}

	public void add(Edge e){
		//e.print();
		int v1=e.getv1();

		int v2=e.getv2();
		Edge tmp;
		if (v1==v2) {
			System.out.println("Self Loop is not allowed!");
			return;
		}
		if (a_list[v1]==null) {
			a_list[v1]=e;
		} else {
			tmp=a_list[v1];
			while (tmp.hasnext(v1)) {
				tmp=tmp.getnext(v1);
			}
			tmp.next(e,v1);
		}

		if (a_list[v2]==null) {
			a_list[v2]=e;
		} else {
			tmp=a_list[v2];
			while (tmp.hasnext(v2)) {
				tmp=tmp.getnext(v2);
			}
			tmp.next(e,v2);
		}
	}

	public Edge find(int v1,int v2){
		Edge tmp=a_list[v1];
		int u1=tmp.getv1();
		int u2=tmp.getv2();
		int cmp=-1;
		if (u1==v1){
			cmp=u2;
		} else {
			cmp=u1;
		}
		while(cmp!=v2 && tmp.hasnext(v1)){
			tmp=tmp.getnext(v1);
			u1=tmp.getv1();
			u2=tmp.getv2();
			if (u1==v1){
				cmp=u2;
			} else {
				cmp=u1;
			}
		}
		if (cmp==v2) return tmp;
		return null;
	}
	

	public boolean coc(){
		boolean[] boo=new boolean[a_list.length];
		Arrays.fill(boo,false);
		for (int i=0;i<a_list.length;i++) {
			// System.out.println("Vertex "+i);
			Edge tmp=a_list[i];

			while (tmp.hasnext(i)){
				// tmp.print();
				if (tmp.type==1) {
					boo[tmp.getv1()]=true;
					boo[tmp.getv2()]=true;
				}
				tmp=tmp.getnext(i);
			} 
			// tmp.print();
			if (tmp.type==1) {
					boo[tmp.getv1()]=true;
					boo[tmp.getv2()]=true;
			}
		}
		boolean flag=true;
		for (int i=0;i<boo.length;i++ ) {
			flag=flag && boo[i];
		}
		return flag;
	}
	
	public void print(){
		for (int i=0;i<a_list.length;i++) {
			System.out.println("Vertex "+i);
			Edge tmp=a_list[i];
			while (tmp.hasnext(i)){
				tmp.print();
				tmp=tmp.getnext(i);
			} 
			tmp.print();
		}
	}
}