public  class Edge{
	 Edge next1;
	 Edge next2;
	 int v1;
	 int v2;
	 int type;
	 int cap;
	 int length;
	 double time;
	 int flow;
	 
	public Edge(int v1t,int v2t,int typet,int capt,int lengtht){
		v1=v1t;
		v2=v2t;
		type=typet;
		cap=capt;
		length=lengtht;
		switch (type) {
			case 0: time=(double) length/0.2;
					break;
			case 1: time=(double) length/0.23;
					break;
		}
		flow=0;
	}

	public int getv1(){
		return v1;
	}

	public int getv2(){
		return v2;
	}

	public void print(){
		String s;
		switch (type) {
			case 0: s="optical";
					break;
			case 1: s="copper";
		}
		System.out.println(v1+" "+v2+" "+type+" "+cap+" "+length);
	}

	public void next(Edge e,int v){
		if(v==v1){
			next1=e;
		}else if(v==v2){
			next2=e;
		} else{
			System.out.println("error input in setnext()!");
			System.exit(0);
		}
        return;
	}

	public boolean hasnext(int v){
        if(v==v1){
			return next1!=null;
        } else if(v==v2){
        	return next2!=null;
        }
		return false;
    }

	public Edge getnext(int v){
		if(v==v1){
			return next1;
		}
		else if(v==v2){
			return next2;
		}
			return null;
	}

	public int getFlow(){  
        return flow;  
    }  
      
    public void setFlow(int f){  
        flow = f;  
    }  


    public int other(int vertex) {
        if      (vertex == v1) return v2;
        else if (vertex == v2) return v1;
        else throw new IllegalArgumentException("invalid endpoint");
    }

    public int other() {
        return v1;
    }
    public double residualCapacityTo(int vertex) {
        if      (vertex == v1) return flow;              // backward edge
        else if (vertex == v2) return cap - flow;   // forward edge
        else throw new IllegalArgumentException("invalid endpoint");
    }

    // public void addResidualFlowTo(int vertex, double delta) {
    //     if (!(delta >= 0.0)) throw new IllegalArgumentException("Delta must be nonnegative");

    //     if      (vertex == v1) flow -= delta;           // backward edge
    //     else if (vertex == v2) flow += delta;           // forward edge
    //     else throw new IllegalArgumentException("invalid endpoint");

    //     // round flow to 0 or capacity if within floating-point precision
    //     if (Math.abs(flow) <= FLOATING_POINT_EPSILON)
    //         flow = 0;
    //     if (Math.abs(flow - capacity) <= FLOATING_POINT_EPSILON)
    //         flow = capacity;

    //     if (!(flow >= 0.0))      throw new IllegalArgumentException("Flow is negative");
    //     if (!(flow <= capacity)) throw new IllegalArgumentException("Flow exceeds capacity");
    // }

    public void clear(){
        flow=0;
    }

    public int from() {
        return v1;
    }

    /**
     * Returns the head vertex of the directed edge.
     * @return the head vertex of the directed edge
     */
    public int to() {
        return v2;
    }

    /**
     * Returns the weight of the directed edge.
     * @return the weight of the directed edge
     */
    public double weight() {
        return time;
    }

    public String toString() {
       return String.format("%d-%d-", v1, v2);
    }
}