/*************************************************************************
 *  Compilation:  javac LZW.java
 *  Execution:    java LZW - < input.txt   (compress)
 *  Execution:    java LZW + < input.txt   (expand)
 *  Dependencies: BinaryIn.java BinaryOut.java
 *
 *  Compress or expand binary input from standard input using LZW.
 *
 *  WARNING: STARTING WITH ORACLE JAVA 6, UPDATE 7 the SUBSTRING
 *  METHOD TAKES TIME AND SPACE LINEAR IN THE SIZE OF THE EXTRACTED
 *  SUBSTRING (INSTEAD OF CONSTANT SPACE AND TIME AS IN EARLIER
 *  IMPLEMENTATIONS).
 *
 *  See <a href = "http://java-performance.info/changes-to-string-java-1-7-0_06/">this article</a>
 *  for more details.
 *
 *************************************************************************/

public class MyLZW {
    private static final int R = 256;        // number of input chars
    private static int L = 512;       // number of codewords = 2^W
    private static int W = 9;         // codeword width begin with 9

    public static void compress(char ch) {
        //init 
        int comp=0;
        int ucmp=0;
        double r1=1;//old ratio: update when resize
        double r2=1;//new ratio: update dynamically
        double ratio=0;
        boolean updated=false;
        String input = BinaryStdIn.readString();
        TST<Integer> st = new TST<Integer>();
        for (int i = 0; i < R; i++)
            st.put("" + (char) i, i);
        int code = R+1;  // R is codeword for EOF

        while (input.length() > 0) {
            String s = st.longestPrefixOf(input);  // Find max prefix match s.
            BinaryStdOut.write(st.get(s), W);      // Print s's encoding.
            int t = s.length();
            ucmp+=8*t;
            comp+=W;
            r2=(double)ucmp/comp;
            ratio=r1/r2;
            if (code == L){//when the symbol table is full
                if (W < 16){
                    W++;
                    L*=2;
                }

                if (W==16){
                    if (ch=='r'){//reset mode
                        W=9;
                        L=512;
                        st = new TST<Integer>();
                        for (int i = 0; i < R; i++)
                            st.put("" + (char) i, i);
                        code = R+1;  // R is codeword for EOF
                        // System.err.println("resized");

                    } else if (ch=='m'){//monitor mode
                        if (!updated){//first time, update old ratio
                            updated=true;
                            r1=r2;
                            ratio=1;
                            System.err.println("full filled");
                        } else {
                            // System.err.printf("%.2f\n",ratio);

                            if (ratio>1.1){//updated & need resize
                                W=9;
                                L=512;
                                st = new TST<Integer>();
                                for (int i = 0; i < R; i++)
                                    st.put("" + (char) i, i);
                                code = R+1;  // R is codeword for EOF
                                updated=false;
                                System.err.println("resized");
                                System.err.println(s);                                
                                System.err.println(ratio);
                            }
                        }// other cases, stay the same
                    }
                }
            }
            if (t < input.length() && code < L){    // Add s to symbol table.
                st.put(input.substring(0, t + 1), code++);

            }
            input = input.substring(t);            // Scan past s in input.
        }
        BinaryStdOut.write(R, W);
        BinaryStdOut.close();
    } 


    public static void expand(char ch) {
        int comp=0;
        int ucmp=0;
        double r1=1;//old ratio: update when resize
        double r2=1;//new ratio: update dynamically
        double ratio=0;
        boolean updated=false;
        String[] st = new String[65536];//2^16
        int i; // next available codeword value
        boolean resized=false;//check what's wrong
        // initialize symbol table with all 1-character strings
        for (i = 0; i < R; i++)
            st[i] = "" + (char) i;
        st[i++] = "";                        // (unused) lookahead for EOF

        int codeword = BinaryStdIn.readInt(W);
        comp+=W;
        if (codeword == R) return;           // expanded message is empty string
        String val = st[codeword];
        ucmp+=8*val.length();
        BinaryStdOut.write(val);
        while (true) {

            if (i==L){
                if (W < 16){
                    W++;
                    L*=2;
                }

                if (W==16){
                    if (ch=='r'){
                        W=9;
                        L=512;
                        for (i = 0; i < R; i++)
                            st[i] = "" + (char) i;
                        st[i++] = "";                        // (unused) lookahead for EOF
                    } else if (ch=='m'){
                        //System.err.println(ratio);

                        if (!updated){//first time, update old ratio
                            updated=true;
                            r1=r2;
                            ratio=1;
                            System.err.println("full filled");
                        } else {
                            if (!(ratio<1.1)){//updated & need resize
                                W=9;
                                L=512;
                                for (i = 0; i < R; i++)
                                    st[i] = "" + (char) i;
                                st[i++] = "";                        // (unused) lookahead for EOF
                                updated=false;
                                System.err.println("resized");
                                resized=true;
                            }// other cases, stay the same
                        }
                    }
                }
            }
            

            codeword = BinaryStdIn.readInt(W);
            comp+=W;
            if (codeword == R) break;
            String s = st[codeword];
            
            r2=(double)ucmp/comp;
            ratio=r1/r2;

            if (i == codeword) s = val + val.charAt(0);   // special case hack
            //dynamic size

            if (i < L) {
                // System.err.println("val is "+val+" s is "+s);//2^9=512
                // System.err.println("i is "+i+" L is "+L);//2^9=512

                st[i++] = val + s.charAt(0);
            }

            



            val = s;
            ucmp+=8*val.length();
            BinaryStdOut.write(val);

        }
        BinaryStdOut.close();
    }



    public static void main(String[] args) {
        char ch=args[1].charAt(0);
        switch (ch) {
            case 'n':
            case 'r':
            case 'm':break;
            default: System.err.println("invalid compress method! (r/m/n)");
                    System.exit(0);
        }
        if      (args[0].equals("-")) compress(ch);
        else if (args[0].equals("+")) expand(ch);
        else throw new IllegalArgumentException("Illegal command line argument");
    }

}
